export class ReviewDto {
  id?: number;
  rating: number;
  review: string;
  reviewTitle: string;
  movieId: number;
}
