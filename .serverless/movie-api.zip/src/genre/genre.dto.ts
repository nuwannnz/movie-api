export class GenreDto {
  id?: number;
  genre: string;
  key: string;
}
